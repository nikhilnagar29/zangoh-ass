## Mid-Session Requirement

- **Account Management Agent (Mid-Session Requirement):**
  - Implement an agent capable of handling customer subscription queries, processing simple subscription changes, and verifying account permissions.
  - Ensure integration with your existing orchestration system so that it interacts seamlessly with the other agents.
  - **Note:** The initial demo logic should be completely replaced with functional code to manage account-related inquiries.
